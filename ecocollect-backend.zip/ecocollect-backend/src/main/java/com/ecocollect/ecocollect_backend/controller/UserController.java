package com.ecocollect.ecocollect_backend.controller;

import com.ecocollect.ecocollect_backend.dto.RegisterRequest;
import com.ecocollect.ecocollect_backend.dto.UserResponse;
import com.ecocollect.ecocollect_backend.entity.Role;
import com.ecocollect.ecocollect_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {
    @Autowired
    private UserService userService;

    // 1. API Đăng ký người dùng mới
    // POST http://localhost:8081/api/v1/users/register
    @PostMapping("/register")
    public ResponseEntity<UserResponse> registerUser(@RequestBody RegisterRequest request){
        UserResponse response = userService.registerUser(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    // 2. API Lấy thông tin user theo ID
    // ví dụ id = 1, GET http://localhost:8081/api/v1/users/1
    @GetMapping("/{id}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable Long id) {
        UserResponse response = userService.getUserById(id);
        return ResponseEntity.ok(response); // Tra ve HTTP Status 200 OK
    }

    // 3. lấy danh sách toàn bộ users
    // GET http://localhost:8081/api/v1/users
    @GetMapping
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        List<UserResponse> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    // 4. lấy danh sách users theo vai trò
    // ví dụ: GET http://localhost:8081/api/v1/users/role/ADMIN
    @GetMapping("/role/{role}")
    public ResponseEntity<List<UserResponse>> getUsersByRole(@PathVariable Role role){
        List<UserResponse> users = userService.getUsersByRole(role);
        return ResponseEntity.ok(users);
    }
}
