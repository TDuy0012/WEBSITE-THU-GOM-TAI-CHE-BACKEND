package com.ecocollect.ecocollect_backend.dto;

// user gửi login bằng email , password
public record AuthRequest(String email, String password) {
}
