package com.ecocollect.ecocollect_backend.dto;

import com.ecocollect.ecocollect_backend.entity.Role;

// hệ thống trả token sau khi xác thực login thành công
public record AuthResponse(String token, Role role) {
}

//note: record - class đặc biệt làm vật chứa dữ liệu hoặc DTO, khi gọi ở class khác công dụng vẫn như một Object bình thường
//lợi ích: jackson đọc các trường của record rất nhanh và chuyển đổi giữa Object <-> Json chính xác:
// VD : JSON {  "token" : "eyJhbGciOi..."  }