package com.ecocollect.ecocollect_backend.dto;

import com.ecocollect.ecocollect_backend.entity.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
// request user gửi các trường này để đăng ký
public class RegisterRequest {
    private String fullname;
    private String email;
    private String password;
    private String phone;
    private Role role;
    private String address;
}
