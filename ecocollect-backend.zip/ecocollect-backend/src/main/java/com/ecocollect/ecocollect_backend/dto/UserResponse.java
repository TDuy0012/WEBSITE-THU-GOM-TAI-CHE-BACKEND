package com.ecocollect.ecocollect_backend.dto;

import com.ecocollect.ecocollect_backend.entity.Role;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Builder
// hệ thống lưu các trường này vào database
public class UserResponse {
    private Long id;
    private String fullname;
    private String email;
    private String phone;
    private Role role;
    private String address;
    private LocalDate createdAt;
}
