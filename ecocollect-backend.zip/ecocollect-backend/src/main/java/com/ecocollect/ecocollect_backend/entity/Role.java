package com.ecocollect.ecocollect_backend.entity;

public enum Role {
    CUSTOMER,
    COLLECTER,
    ADMIN
}
