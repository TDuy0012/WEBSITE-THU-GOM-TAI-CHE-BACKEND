package com.ecocollect.ecocollect_backend.security;

import com.ecocollect.ecocollect_backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
// interface UserDetailsService duy nhất chỉ công việc lấy dữ liệu từ repository (entity users)
// add vào interface UserDetails. gói lại các trường thông tin cần cho việc xác thực token
public class CustomUserDetailsService implements UserDetailsService {
    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException{
        var user = userRepository.findByEmail(email).orElseThrow(() -> new UsernameNotFoundException("Không tìm thấy người dùng với email: " +email));

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getEmail())
                .password(user.getPassword())
                .roles(user.getRole().name())   //name :USER, COLLECTOR, ADMIN
                .build();
    }

    //note : org.springframework.security.core.userdetails.User
    // - chỉ định cho spring biết trả về class User của spring security, không phải class User entity
    // - không thể import từ đầu file vì xung đột với User entity cùng tên.
}
