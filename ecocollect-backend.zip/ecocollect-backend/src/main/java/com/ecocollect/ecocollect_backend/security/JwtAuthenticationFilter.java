package com.ecocollect.ecocollect_backend.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component //đánh dấu lớp này là Spring bean để spring tự động quản lý và inject vào SecurityConfig
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter { // lọc đúng 1 lần cho mỗi request
    final JwtService jwtService;
    final CustomUserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
            ) throws ServletException, IOException {
        final String authHeader = request.getHeader("Authorization"); //đọc chuỗi Authorization trong Header
        final String jwt;
        final String userEmail;

        // không có token
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response); // -> cho qua. Nhưng vẫn tự động chặn đối với đường dẫn bảo mật
            return;
        }

        // có token
        jwt = authHeader.substring(7); // cắt bỏ chuỗi "Bearer " để lấy chuỗi token
        userEmail = jwtService.extractUsername(jwt);

        if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) { //người dùng này chưa được xác thực ở request hiện tại
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(userEmail); //lấy email từ token để tìm user trong databsae

            if (jwtService.isTokenValid(jwt, userDetails)) {
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                        userDetails, //username
                        null, // không cần dùng mật khẩu
                        userDetails.getAuthorities() // list quyền hạn
                );
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request)); //bổ sung địa chỉ IP, session id,...
                SecurityContextHolder.getContext().setAuthentication(authToken); // xác thực thành công
            }
        }
        filterChain.doFilter(request, response); //chuyển request sang filter tiếp theo
    }

    // bỏ qua kiểm tra token với request đăng ký và đăng nhập lần đầu
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        String path = request.getRequestURI();
        return path.startsWith("/api/auth/") || path.startsWith("/api/v1/users/register");
    }
}
