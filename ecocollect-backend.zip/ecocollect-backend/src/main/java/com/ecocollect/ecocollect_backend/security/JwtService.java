package com.ecocollect.ecocollect_backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;


// nhiệm vụ: tạo token từ user và kiểm tra token
@Service
public class JwtService {
    // lấy secretKey và expiration-ms từ file application.yaml
    @Value("${jwt.secret}")
    private String secretKey;

    @Value(("${jwt.expiration-ms}"))
    private long jwtExpirationMs;

    // dùng thuật toán HMAC-SHA để Spring / JJWT tiến hành ký và verify token ( biến chuỗi secretKey thuần sang đối tượng SecretKey)
    private SecretKey getSigningKey(){
        return Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.UTF_8));
    }

    // sinh token mới
    public String generateToken(UserDetails userDetails){
        // lấy role add vào claims khi gửi token lên server, giúp phân biệt quyền user
        Map<String, Object> claims = new HashMap<>();

        String role = userDetails.getAuthorities().stream()
                .findFirst()
                .map(GrantedAuthority::getAuthority).orElse("CUSTOMER");

        return Jwts.builder()
                .subject(userDetails.getUsername())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis()  + jwtExpirationMs))
                .signWith(getSigningKey())
                .compact();
    }

    // (hàm dùng chung) trong jwt token có gói Claims chứa các cặp key-value: subject, expiration, issuesAt, custom fields,...
    public <T> T extractClaim(String token, Function<Claims, T> claimResolver) { // hàm chỉ định trường T chính xác muốn trích xuất từ Claims
        final Claims claims = extractAllClaims(token);
        return claimResolver.apply(claims);
    }

    // trích xuất username từ token
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    // trích xuất thời hạn
    public Date extractExpiration(String token){
        return extractClaim(token, Claims::getExpiration);
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    // kiểm tra token hợp lệ
    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    // kiểm tra hết hạn token
    public boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }
}
