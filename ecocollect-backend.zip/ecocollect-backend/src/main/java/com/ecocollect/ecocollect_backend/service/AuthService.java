package com.ecocollect.ecocollect_backend.service;

import com.ecocollect.ecocollect_backend.dto.AuthRequest;
import com.ecocollect.ecocollect_backend.dto.AuthResponse;
import com.ecocollect.ecocollect_backend.entity.Role;
import com.ecocollect.ecocollect_backend.entity.User;
import com.ecocollect.ecocollect_backend.security.CustomUserDetailsService;
import com.ecocollect.ecocollect_backend.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final AuthenticationManager authenticationManager;
    private final CustomUserDetailsService userDetailsService;
    private final JwtService jwtService;

    public AuthResponse authenticate(AuthRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.email(), request.password())
        );

        var userDetails = userDetailsService.loadUserByUsername(request.email());

        Role role = null;
        if (userDetails instanceof User user) {
            role = user.getRole();
        }
        var jwtToken = jwtService.generateToken(userDetails);
        return new AuthResponse(jwtToken, role);
    }
}
