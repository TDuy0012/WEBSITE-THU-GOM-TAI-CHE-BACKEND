package com.ecocollect.ecocollect_backend.service;

import com.ecocollect.ecocollect_backend.dto.RegisterRequest;
import com.ecocollect.ecocollect_backend.dto.UserResponse;
import com.ecocollect.ecocollect_backend.entity.Role;

import java.util.List;

public interface UserService {


    UserResponse registerUser(RegisterRequest request);  //dang ky tai khoan moi
    UserResponse getUserById(Long id);
    List<UserResponse> getAllUsers();
    List<UserResponse> getUsersByRole(Role role);
}
