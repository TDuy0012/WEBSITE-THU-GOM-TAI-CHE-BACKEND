package com.ecocollect.ecocollect_backend.service.impl;

import com.ecocollect.ecocollect_backend.dto.RegisterRequest;
import com.ecocollect.ecocollect_backend.dto.UserResponse;
import com.ecocollect.ecocollect_backend.entity.Role;
import com.ecocollect.ecocollect_backend.entity.User;
import com.ecocollect.ecocollect_backend.repository.UserRepository;
import com.ecocollect.ecocollect_backend.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserResponse registerUser(RegisterRequest request){
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email đã được sử dụng!");
        }

        String encodedPassword = passwordEncoder.encode(request.getPassword());

        User user = User.builder()
                .fullname(request.getFullname())
                .email(request.getEmail())
                .password(encodedPassword)
                .phone(request.getPhone())
                .role(request.getRole() != null ? request.getRole() : Role.CUSTOMER)
                .address(request.getAddress())
                .build();

        User savedUser = userRepository.save(user);

        return mapToUserresponse(savedUser);
    }

    @Override
    public UserResponse getUserById(Long id){
        User user = userRepository.findById(id).orElseThrow(()-> new RuntimeException("Không tìm thấy người dùng nào."));
        return mapToUserresponse(user);
    }

    @Override
    public List<UserResponse> getAllUsers(){
        return userRepository.findAll()
                .stream()
                .map(this::mapToUserresponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<UserResponse> getUsersByRole(Role role) {
        return userRepository
                .findByRole(role)
                .stream().map(this::mapToUserresponse)
                .collect(Collectors.toList());
    }
    // hàm chuyển đổi entity -> dto
    private UserResponse mapToUserresponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .fullname(user.getFullname())
                .email(user.getEmail())
                .phone(user.getPhone())
                .role(user.getRole())
                .address(user.getAddress())
                .build();
    }

}
